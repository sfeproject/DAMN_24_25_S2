package com.profiltel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
	private EditText edNom;
    private Spinner spContinent;
    private SeekBar seekNbVariete;
    private CheckBox chConsommable;
    private Button btnEnregister;
	private Button btnAfficher;
	private Button btnPasser;
	private Button btnPasserParcel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique4();
    }

    private void initGraphique4() {
        edNom=findViewById(R.id.edNom);
        spContinent=findViewById(R.id.spContinent);
        seekNbVariete=findViewById(R.id.seekNbVariete);
        chConsommable=findViewById(R.id.chConsommable);
        btnEnregister=findViewById(R.id.btnEnregister);
        btnAfficher=findViewById(R.id.btnAfficher);
        btnPasser=findViewById(R.id.btnPasser);
        btnPasserParcel=findViewById(R.id.btnPasserParcel);

    }
}