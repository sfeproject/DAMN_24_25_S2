package com.profiltel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
	private EditText edCouleur;
    private Spinner spType;
    private SeekBar seekNbFleur;
    private CheckBox chExterne;
    private Button btnEnregister;
	private Button btnAfficher;
	private Button btnPasser;
	private Button btnPasserParcel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique8();
    }

    private void initGraphique8() {
        edCouleur=findViewById(R.id.edCouleur);
        spType=findViewById(R.id.spType);
        seekNbFleur=findViewById(R.id.seekNbFleur);
        chExterne=findViewById(R.id.chExterne);
        btnEnregister=findViewById(R.id.btnEnregister);
        btnAfficher=findViewById(R.id.btnAfficher);
        btnPasser=findViewById(R.id.btnPasser);
        btnPasserParcel=findViewById(R.id.btnPasserParcel);

    }
}