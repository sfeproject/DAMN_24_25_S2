package com.profiltel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
	private EditText edNom;
    private Spinner spType;
    private SeekBar seekNbNiveau;
    private CheckBox chFragile;
    private Button btnEnregister;
	private Button btnAfficher;
	private Button btnPasser;
	private Button btnPasserParcel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique6();
    }

    private void initGraphique6() {
        edNom=findViewById(R.id.edNom);
        spType=findViewById(R.id.spType);
        seekNbNiveau=findViewById(R.id.seekNbNiveau);
        chFragile=findViewById(R.id.chFragile);
        btnEnregister=findViewById(R.id.btnEnregister);
        btnAfficher=findViewById(R.id.btnAfficher);
        btnPasser=findViewById(R.id.btnPasser);
        btnPasserParcel=findViewById(R.id.btnPasserParcel);

    }
}